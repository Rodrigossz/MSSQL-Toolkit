SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
IF OBJECT_ID('tempdb..#MissingIndexInfo','U') IS NOT NULL 
	DROP TABLE #MissingIndexInfo;
IF OBJECT_ID('tempdb..#MissingIdxSuperInfo','U') IS NOT NULL 
	Drop Table #MissingIdxSuperInfo;
IF OBJECT_ID('tempdb..#top20','U') IS NOT NULL 
	Drop Table #top20;

SET NOCOUNT ON;

WITH XMLNAMESPACES  
   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
    
SELECT query_plan, plan_handle,sql_handle,execution_count,
       n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS sql_text, 
       --n.value('(//MissingIndexGroup/@Impact)[1]', 'FLOAT') AS impact, 
       DB_ID(REPLACE(REPLACE(n.value('(//MissingIndex/@Database)[1]', 'VARCHAR(128)'),'[',''),']','')) AS database_id, 
       OBJECT_ID(n.value('(//MissingIndex/@Database)[1]', 'VARCHAR(128)') + '.' + 
           n.value('(//MissingIndex/@Schema)[1]', 'VARCHAR(128)') + '.' + 
           n.value('(//MissingIndex/@Table)[1]', 'VARCHAR(128)')) AS OBJECT_ID, 
       n.value('(//MissingIndex/@Database)[1]', 'VARCHAR(128)') + '.' + 
           n.value('(//MissingIndex/@Schema)[1]', 'VARCHAR(128)') + '.' + 
           n.value('(//MissingIndex/@Table)[1]', 'VARCHAR(128)')  
       AS STATEMENT
INTO #MissingIndexInfo 
FROM  
( 
   SELECT query_plan,plan_handle,sql_handle,execution_count
   FROM (    
           SELECT DISTINCT plan_handle,sql_handle,execution_count
           FROM sys.dm_exec_query_stats
         ) AS qs 
       OUTER APPLY sys.dm_exec_query_plan(qs.plan_handle) tp     
   WHERE tp.query_plan.exist('//MissingIndex')=1 
) AS tab (query_plan,plan_handle,sql_handle,execution_count) 
CROSS APPLY query_plan.nodes('//StmtSimple') AS q(n) 
WHERE n.exist('QueryPlan/MissingIndexes') = 1 
	And DB_ID(REPLACE(REPLACE(n.value('(//MissingIndex/@Database)[1]', 'VARCHAR(128)'),'[',''),']','')) = DB_ID()
  
CREATE CLUSTERED INDEX ci_sqlhandle ON #MissingIndexInfo(sql_handle)

SELECT mii.database_id,mii.object_id,Mii.plan_handle,mii.sql_handle	,mii.execution_count
	,CA.equality_columns,CA.inequality_columns,CA.included_columns
	,CA.Impact
	--,cahash.query_hash
	--,cahash.query_plan_hash
	--,CA.name as ProcName
	--,query_text_part
	,CA.unique_compiles,CA.user_seeks,CA.avg_total_user_cost,CA.avg_user_impact,CA.last_user_seek
Into #MissingIdxSuperInfo
FROM #MissingIndexInfo MII
CROSS APPLY ( SELECT mid.database_id,mid.object_id,mid.equality_columns
	, mid.inequality_columns
	, mid.included_columns
	,migs.unique_compiles, migs.user_seeks, migs.avg_total_user_cost,migs.avg_user_impact
	,migs.last_user_seek
	,(avg_total_user_cost * avg_user_impact) * (user_seeks + user_scans) AS Impact

	FROM sys.dm_db_missing_index_group_stats AS migs 
		INNER JOIN sys.dm_db_missing_index_groups AS mig 
			ON migs.group_handle = mig.index_group_handle 
		INNER JOIN sys.dm_db_missing_index_details AS mid 
			ON mig.index_handle = mid.index_handle 
			AND mid.database_id = DB_ID() 

		) CA
--CROSS APPLY (
--	SELECT qs.query_hash,qs.sql_handle,qs.query_plan_hash
--		FROM sys.dm_exec_query_stats qs
--		WHERE qs.sql_handle = mii.sql_handle
--		--GROUP BY qs.sql_handle
--	) cahash
WHERE 1 =1
	AND ca.database_id = mii.database_id
	AND ca.object_id = mii.OBJECT_ID
--	AND cahash.sql_handle = mii.sql_handle

Select Distinct Top 20 plan_handle,Max(Impact) as Impact
	Into #top20
	From #MissingIdxSuperInfo
	Group by plan_handle
	Order by Impact Desc;

With finalsel as (
Select SI.*

	,ROW_NUMBER() over (partition by si.equality_columns, si.inequality_columns,si.execution_count
							order by si.impact desc) as RowNum
	From #MissingIdxSuperInfo SI
		Inner Join #top20 t
			On t.plan_handle = SI.plan_handle
)
Select fs.*
	,mii.query_plan
	,mii.sql_text as sql_text_inExecplan
	,mii.statement as DB_Schema_Obj
	,sub.name
	,ROW_NUMBER() over (partition by fs.plan_handle,sub.name order by sub.name) as InnerRowNum
	,(Select COUNT(*) 
		from sys.dm_exec_query_stats s 
		where s.query_hash = sub.query_hash
		--Group by s.query_hash
				) as SimilarQueries
	,(Select COUNT(*) 
		from sys.dm_exec_query_stats s 
		where s.query_plan_hash = sub.query_plan_hash
		--Group by s.query_hash
				) as SimilarQueryPlans
	,(	SELECT COUNT(qs.query_hash)
		FROM sys.dm_exec_query_stats qs
		WHERE qs.sql_handle = mii.sql_handle
		GROUP BY qs.sql_handle) as QueriesRelatedtoPlan
	,(SELECT 
			REPLACE
			(
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
					CONVERT
					(
						NVARCHAR(MAX),
						N'--' + NCHAR(13) + NCHAR(10) + ist.text + NCHAR(13) + NCHAR(10) + N'--' COLLATE Latin1_General_Bin2
					),
					NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),
					NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
					NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),
					NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
					NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),
					NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),NCHAR(0),N''
			) AS [processing-instruction(query)]
			FROM sys.dm_exec_sql_text(fs.sql_handle) AS ist 
		FOR XML PATH(''),TYPE
	) AS QueryDef
	,cp.objtype
	Into #finalsel
	From finalsel fs
		Inner Join #MissingIndexInfo MII
			On fs.database_id = mii.database_id
			And fs.object_id = mii.object_id
			And fs.plan_handle = Mii.plan_handle
		Inner Join sys.dm_exec_cached_plans cp
			On fs.plan_handle = cp.plan_handle
		CROSS APPLY (Select top 1 ISNULL(p.name,'ADHOC') as NAME,query_hash,query_plan_hash
						From sys.dm_exec_query_stats qs
						CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
						Left Outer Join sys.procedures p
							On qt.objectid = p.object_id
						Where qs.plan_handle = fs.plan_handle) sub
		--OUTER APPLY (SELECT plan_handle,cp.objtype
		--				FROM sys.dm_exec_cached_plans cp
		--				WHERE cp.plan_handle = fs.plan_handle) subo
	Where RowNum = 1
	--Order by Impact Desc
	;

Select * 
	from #finalsel
	Where InnerRowNum = 1
	Order by Impact Desc;
	
DROP TABLE #MissingIndexInfo;
Drop Table #MissingIdxSuperInfo;
Drop Table #top20;
Drop Table #finalsel